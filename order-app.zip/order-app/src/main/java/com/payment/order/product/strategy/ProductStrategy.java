package com.payment.order.product.strategy;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import com.payment.order.product.service.IProductService;

public class ProductStrategy {

  /** The service list. */
  private final List<IProductService> serviceList;

  /**
   * Instantiates a new product factory.
   *
   * @param serviceList
   *          the service list
   */
  @Autowired
  public ProductStrategy(List<IProductService> serviceList) {
    this.serviceList = Optional.ofNullable(serviceList).orElse(null);

  }

  /**
   * Gets the service.
   *
   * @param s
   *          the s
   * @return the service
   */
  public IProductService getService(String s) {
    return serviceList.stream().filter((IProductService productService) -> productService.supports(s)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }
}
