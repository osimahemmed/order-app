
package com.payment.order.serviceimpl;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import com.payment.order.exception.BaseException;
import com.payment.order.product.service.IProductService;
import com.payment.order.request.SearchRequest;

/**
 * The Class PhysicalPaymentService.
 */
@Component("PhysicalPaymentService")
public class PhysicalPaymentService implements IProductService {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(PhysicalPaymentService.class.getName());

  /**
   * Instantiates a new Physical Payment Service
   */
  public PhysicalPaymentService() {
    super();
  }

  @Override
  public boolean supports(String serviceName) {
    return "physicalPayment".equalsIgnoreCase(serviceName);
  }

  @Override
  public JSONObject processPayment(SearchRequest request) throws BaseException, JSONException {
    LOGGER.info("Entering the method processPayment");
    JSONObject json = new JSONObject();
    // generate packing slip for shipping and generate commission payment.
    // generatePakcingSlip();
    json.put("pk_id", "retss");
    return json;
  }

}
