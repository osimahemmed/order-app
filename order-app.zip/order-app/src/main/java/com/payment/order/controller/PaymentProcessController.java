
/*
* This software is the confidential and proprietary information of
* XYZ corporation.
*
*/

package com.payment.order.controller;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.payment.order.exception.BaseException;
import com.payment.order.product.service.IProductService;
import com.payment.order.product.strategy.ProductStrategy;
import com.payment.order.request.SearchRequest;

/**
 * The Class PaymentProcessController.
 * 
 * @author osiahemm
 */
@RestController
@CrossOrigin("*")
@RequestMapping(path = "/rules-engine")
public class PaymentProcessController {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(PaymentProcessController.class);

  /** The product Strategy. */
  @Autowired
  private ProductStrategy productStrategy;

  /**
   * Default Constructor.
   */
  public PaymentProcessController() {
    super();

  }

  /**
   * This method will be used for process payment.
   *
   * @param request
   *          the search request
   * @param req
   *          the httpServletRequest
   * @return the json
   * @throws BaseException
   *           the base exception
   */
  @PostMapping(path = "/evaluate", produces = MediaType.APPLICATION_JSON_VALUE)
  public JSONObject processPayment(@RequestBody SearchRequest request, HttpServletRequest req) throws BaseException {
    LOGGER.info("Entering the method processPayment");
    final IProductService productService = productStrategy.getService(request.getPaymentType());
    JSONObject jsonResponse;
    try {
      jsonResponse = productService.processPayment(request);
    }
    catch (JSONException e) {
      throw new BaseException("Error while processing procesPayment", e);
    }

    LOGGER.info("Exiting the method processPayment");
    return jsonResponse;
  }

}
