package com.payment.order.product.service;

import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import com.payment.order.exception.BaseException;
import com.payment.order.request.SearchRequest;

public interface IProductService {

  /**
   * This method resolve the expected service class. it will take the bean name
   * and resolve on the basis of that if it is the right service class called or
   * not.
   *
   * @param serviceName
   *          the serviceName
   * @return true, if successful
   */
  boolean supports(String serviceName);

  /**
   * This method get the document required for document module.
   * 
   * @param request
   *          the request
   * @return json object
   * @throws BaseException
   *           the exception
   * @throws IOException
   *           the IOException
   * @throws JSONException 
   */
  JSONObject processPayment(SearchRequest request) throws BaseException, JSONException;

}
