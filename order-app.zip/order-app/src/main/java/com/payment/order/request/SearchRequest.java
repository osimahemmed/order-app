
package com.payment.order.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * The Class SearchRequest.
 * 
 * @author osiahemm
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "q", "paymentType" })
public class SearchRequest {

  /** The q. */
  @JsonProperty("q")
  private String q;

  /** The payment type. */
  @JsonProperty("paymentType")
  private String paymentType;

  /**
   * Default Constructor.
   */
  public SearchRequest() {
    super();

  }

  /**
   * Gets the q.
   *
   * @return the q
   */
  @JsonProperty("q")
  public String getQ() {
    return q;
  }

  /**
   * Sets the q.
   *
   * @param q
   *          the new q
   */
  @JsonProperty("q")
  public void setQ(String q) {
    this.q = q;
  }

  /**
   * @return the paymentType
   */
  public String getPaymentType() {
    return paymentType;
  }

  /**
   * @param paymentType
   *          the paymentType to set
   */
  public void setPaymentType(String paymentType) {
    this.paymentType = paymentType;
  }
}
