package com.payment.order.exception;

import org.springframework.http.HttpStatus;

/**
 * The Class BaseException.
 */
public class BaseException extends Exception {

  /** The Constant ERROR_CODE. */
  private static final String ERROR_CODE = "Error code: ";

  /** The Constant ERROR_DETAIL. */
  private static final String ERROR_DETAIL = "Error detail: ";

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The error code. */
  private String errorCode;

  /** The exception. */
  private Exception exception;

  /** The status. */
  private HttpStatus status;

  /**
   * Instantiates a new base exception.
   *
   * @param errorMessage
   *          the error message
   */
  public BaseException(String errorMessage) {
    super(ERROR_DETAIL + errorMessage);
  }

  /**
   * Instantiates a new base exception.
   *
   * @param errorMessage
   *          the error message
   * @param exception
   *          the exception
   */
  public BaseException(String errorMessage, Exception exception) {
    super(ERROR_DETAIL + errorMessage, exception);
  }

  /**
   * Instantiates a new base exception.
   *
   * @param errorCode
   *          the error code
   * @param errorMessage
   *          the error message
   */
  public BaseException(String errorCode, String errorMessage) {
    super(ERROR_CODE + errorCode + " " + ERROR_DETAIL + errorMessage);
  }

  /**
   * Instantiates a new base exception.
   *
   * @param errorCode
   *          the error code
   * @param errorMessage
   *          the error message
   * @param exception
   *          the exception
   */
  public BaseException(String errorCode, String errorMessage, Exception exception) {
    super(ERROR_CODE + errorCode + " " + ERROR_DETAIL + errorMessage, exception);
  }

  /**
   * Instantiates a new base exception.
   *
   * @param errorCode
   *          the error code
   * @param errorMessage
   *          the error message
   * @param statusCode
   *          the status code
   * @param exception
   *          the exception
   */
  public BaseException(String errorCode, String errorMessage, HttpStatus statusCode, Exception exception) {
    super(ERROR_DETAIL + errorMessage, exception);
    this.exception = exception;
    this.status = statusCode;
    this.errorCode = errorCode;
  }

  /**
   * Gets the error code.
   *
   * @return the error code
   */
  public String getErrorCode() {
    return errorCode;
  }

  /**
   * Gets the exception.
   *
   * @return the exception
   */
  public Exception getException() {
    return exception;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public HttpStatus getStatus() {
    return status;
  }

  /**
   * Sets the error code.
   *
   * @param errorCode
   *          the new error code
   */
  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  /**
   * Sets the status.
   *
   * @param status
   *          the new status
   */
  public void setStatus(HttpStatus status) {
    this.status = status;
  }

}
