
package com.payment.order.serviceimpl;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import com.payment.order.exception.BaseException;
import com.payment.order.product.service.IProductService;
import com.payment.order.request.SearchRequest;

/**
 * The Class UpgradeMemberPaymentService.
 */
@Component("UpgradeMemberPaymentService")
public class UpgradeMemberPaymentService implements IProductService {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(UpgradeMemberPaymentService.class.getName());

  /**
   * Instantiates a new Physical Payment Service
   */
  public UpgradeMemberPaymentService() {
    super();
  }

  @Override
  public boolean supports(String serviceName) {
    return "upgradeMembershipPayment".equalsIgnoreCase(serviceName);
  }

  @Override
  public JSONObject processPayment(SearchRequest request) throws BaseException, JSONException {
    LOGGER.info("Entering the method processPayment");
    JSONObject json = new JSONObject();
    // call upgrade method and send email 
    json.put("result", "upgraded successfully");
    return json;
  }
}
