package com.payment.order.product.strategy;

import static org.junit.Assert.assertNotNull;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import com.payment.order.product.service.IProductService;
import com.payment.order.serviceimpl.BookPaymentService;
import com.payment.order.serviceimpl.PhysicalPaymentService;

@RunWith(MockitoJUnitRunner.class)
public class ProductStrategyTest {

  @InjectMocks
  private ProductStrategyTest productStrategy;

  @Test
  public void testGetService() {
    List<IProductService> serviceList = new ArrayList<>();
    serviceList.add(new PhysicalPaymentService());
    List<IProductService> spyList = Mockito.spy(serviceList);
    spyList.add(new BookPaymentService());
    ProductStrategy documentFactory = new ProductStrategy(spyList);
    IProductService service = documentFactory.getService("physicalPayment");
    assertNotNull(service);
  }

}
