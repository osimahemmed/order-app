package com.payment.order.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import com.payment.order.exception.BaseException;
import com.payment.order.request.SearchRequest;
import com.payment.order.serviceimpl.BookPaymentService;

@RunWith(MockitoJUnitRunner.class)
public class BookPaymentServiceTest {

  @InjectMocks
  private BookPaymentService bookPaymentService;

  @Mock
  private SearchRequest request;

  @Test
  public void testSupports() {
    assertTrue("Result", bookPaymentService.supports("bookPayment"));
  }

  @Test
  public void testProcessPayment() throws BaseException, JSONException {
    assertNotNull("Response", bookPaymentService.processPayment(request));
  }

}
