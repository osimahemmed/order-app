package com.payment.order.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import javax.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import com.payment.order.controller.PaymentProcessController;
import com.payment.order.exception.BaseException;
import com.payment.order.product.strategy.ProductStrategy;
import com.payment.order.request.SearchRequest;
import com.payment.order.serviceimpl.PhysicalPaymentService;

@RunWith(MockitoJUnitRunner.class)
public class PaymentProcessControllerTest {

  @InjectMocks
  private PaymentProcessController paymentProcessController;

  @Mock
  private SearchRequest request;

  /** The req. */
  @Mock
  HttpServletRequest req;

  @Mock
  private ProductStrategy productFactory;

  @Mock
  private PhysicalPaymentService physicalPaymentService;

  @Test
  public void testProcessPayment() throws BaseException, JSONException {
    when(request.getPaymentType()).thenReturn("physicalPayment");
    when(productFactory.getService("physicalPayment")).thenReturn(physicalPaymentService);
    when(physicalPaymentService.processPayment(request)).thenReturn(Mockito.mock(JSONObject.class));
    assertNotNull("response", paymentProcessController.processPayment(request, req));
  }

  @Test(expected = BaseException.class)
  public void testProcessPaymentException() throws BaseException, JSONException {
    when(request.getPaymentType()).thenReturn("physicalPayment");
    when(productFactory.getService("physicalPayment")).thenReturn(physicalPaymentService);
    when(physicalPaymentService.processPayment(request)).thenThrow(JSONException.class);
    assertNotNull("response", paymentProcessController.processPayment(request, req));
  }

}
